package com.app.userService.Service;

import  java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.userService.Model.BookingModel;
import com.app.userService.Model.FlatModel;
import com.app.userService.Model.UserModel;
import com.app.userService.Repo.BookingRepo;
import com.app.userService.Repo.FlatRepo;
import com.app.userService.Request.FlatRequest;
import com.app.userService.Request.UserRequest;

@Service
public class FlatService{
    @Autowired
    FlatRepo flatRepo;
    @Autowired
    BookingRepo bookingRepo;

  
    public void bookingModel(FlatRequest flat)throws  Exception{
    	try {
		 	FlatModel flatObj = flatRepo.findById(flat.getId()).orElseThrow(()->new Exception("No Flat found"));;
	        BookingModel bModel =new BookingModel();
	        bModel.setUser_id(flat.getUserId());
	        bModel.setFlat_id(flatObj.getId());
	        //bModel.setBooking_date(new LocalDate());
	        bookingRepo.save(bModel);
    	}catch(Exception e) {
    		throw e;
    	}
       
        
    }
    public void createFlat(FlatRequest req){
        FlatModel flatModel = new FlatModel();
        flatModel.setAddress(req.getAddress());
        flatModel.setIsApproved(0);
        flatModel.setPincode(req.getPincode());
        flatModel.setSqft(req.getSqft());
        flatModel.setRent(req.getRent());
        flatModel.setBhk(req.getBhk());
        flatRepo.save(flatModel);
    }

    public List<FlatModel> searchFlat(FlatRequest req){
    	 return flatRepo.findAll();
    }
    public List<FlatModel> getAll(){
        return flatRepo.findAll();
    }
    public void approveFlat(FlatRequest req) throws Exception{
        FlatModel flatModel = flatRepo.findById(req.getId()).orElseThrow(()->new Exception("No Flat Found"));
        flatModel.setIsApproved(req.getIsApprove());
        flatRepo.save(flatModel);
    }
}

package com.app.userService.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.userService.Model.BookingModel;
import com.app.userService.Model.FlatModel;
import com.app.userService.Model.UserModel;
import com.app.userService.Repo.BookingRepo;
import com.app.userService.Repo.FlatRepo;
import com.app.userService.Repo.UserRepo;
import com.app.userService.Request.FlatRequest;
import com.app.userService.Request.UserRequest;


@Service
public class UserService {

	@Autowired
	FlatRepo flatRepo;
	
    @Autowired
    UserRepo userRepo;
    

    public UserModel userLogin(UserRequest user)throws  Exception{
        UserModel userObj = userRepo.findByEmailAndPassword(user.getEmail(),user.getPassword(),user.getUser_type()).orElseThrow(()->new Exception("No User found"));
        return  userObj;
    }
   
    public List<UserModel> getAllUsers(){
       return userRepo.findAll();
    }

    public void userOrAdminRegister(UserRequest user){
        UserModel userModel = new UserModel();
        userModel.setEmail(user.getEmail());
        userModel.setName(user.getName());
        userModel.setPassword(user.getPassword());
        userModel.setUser_type(user.getUser_type());
        userRepo.save(userModel);
    }

}

package com.app.userService.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.userService.Model.FlatModel;
import com.app.userService.Request.FlatRequest;
import com.app.userService.Response.GeneralResponse;
import com.app.userService.Service.FlatService;

@RequestMapping("flat")
@RestController
public class FlatController {
	
    @Autowired
    FlatService flatService;

    @PostMapping("create")
    public ResponseEntity<?> createFlat(@RequestBody  FlatRequest flatRequest){
        try{
            flatService.createFlat(flatRequest);
            return ResponseEntity.ok(new GeneralResponse("created."));
        }catch (Exception e){
            return ResponseEntity.badRequest().body(new GeneralResponse("Error"));
        }
    }
    
    @PostMapping("search")
    public ResponseEntity<?> searchFlat(@RequestBody FlatRequest flatRequest){
        try{
            List<FlatModel> res = flatService.searchFlat(flatRequest);
            return ResponseEntity.ok(res);
        }catch (Exception e){
            return ResponseEntity.badRequest().body(new GeneralResponse("Error"));
        }
    }
    
    @PostMapping("getall")
    public ResponseEntity<?> getAllFlat(){
        try{
            List<FlatModel> res = flatService.getAll();
            return ResponseEntity.ok(res);
        }catch (Exception e){
            return ResponseEntity.badRequest().body(new GeneralResponse("Error"));
        }
    }
    
    
    @PostMapping("approveOrReject")
    public ResponseEntity<?> approveOrReject(@RequestBody FlatRequest flatRequest){
        try{
            flatService.approveFlat(flatRequest);
            return ResponseEntity.ok(new GeneralResponse("ok"));
        }catch (Exception e){
            return ResponseEntity.badRequest().body(new GeneralResponse("Error"));
        }
    }
}


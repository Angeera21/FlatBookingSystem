package com.app.userService.Config;

public class WebMvcConfig {

}
